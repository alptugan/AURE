#pragma once

#include "ofMain.h"
#include "ofxGui.h"
#include "info.h"

// Todo:
/*
 1- Animate between iterations
 2- Logo Design
 3- Save configuration file
 4- Load selected conf file
 5- Save as pdf 3D space (convert mesh to vector of lines)
 
 */

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
    
    
    ofEasyCam cam;
    ofLight light;

    
    glm::vec3 randomPointOnSphere();
    ofMesh world;
    ofMesh sphereCustom( float radius, int res, ofPrimitiveMode mode );
    void generateSphereCoord(float _r, int _t);
    
    // SUpershape methods
    float superShape(float _theta, float _m1, float _m2, float n1, float n2, float n3, float _a, float _b);
    
    vector<ofColor> rainbow;
    vector<ofColor> bw;
    
    
    // Screen As Jpg
    ofPixels pix;
    ofFbo fbo;
    
    
    // GUI
    ofParameter<bool> showGui = {"Show/Hide GUI", true};
    info infoTxt;
    
    ofxPanel gui;
    // "Set Lights & Environment Porperties"
    ofxPanel spaceGUI;
    ofParameter<glm::vec3> light1Pos;
    ofParameter<bool> showLight1;
    ofParameter<bool> invertBg = {"Invert Background", true};
    
    ofParameterGroup sfGui1;
    ofParameterGroup sfGui2;
    ofParameterGroup meshGui;
    //ofParameter<float> theta;
    ofParameter<float> m11;
    ofParameter<float> m12;
    ofParameter<float> n11;
    ofParameter<float> n12;
    ofParameter<float> n13;
    ofParameter<float> a1;
    ofParameter<float> b1;
    
    
    ofParameter<float> m21;
    ofParameter<float> m22;
    ofParameter<float> n21;
    ofParameter<float> n22;
    ofParameter<float> n23;
    ofParameter<float> a2;
    ofParameter<float> b2;
    
    ofParameter<float> radius;
    ofParameter<int> total;
    ofParameter<ofColor> strokeColor;
    ofParameter<ofColor> fillColor = {"Set Solid Fill Color", ofColor(0), ofColor(0), ofColor(255)};
    ofParameter<int> setMeshFillMode = {"Set Fill Mode", 0, 0, 2};
    ofParameter<bool> drawWireframe;
    ofParameter<bool> drawMesh;
    ofParameter<string> fileName = {"Set File Name",""};
    
    ofParameter<bool> animation1;
    ofParameter<bool> animation2;
    ofxButton iterationBtn;
    void iterationBtnHandler();
    
    float rotValX;
    void animation1Handler(bool &_v);
    
    
    ofxPanel mainGui;
    ofxButton saveBtn;
    ofxButton saveAsPngBtn;
    ofParameter<void> loadSettingsBtn = {"Load File"};
    void loadFile();
    
    void saveBtnHandler();
    void saveAsPngBtnHandler();
    bool saveScreen;
    
    ofParameter<bool> info;
    ofParameter<bool> help;
    
    
    
    // Drop down menu
    vector<string> menuItems;
    int selectedId;
    ofParameterGroup itemList;
    vector<ofParameter<bool>> items;
    void filesCallback(bool & _val);
    
    // Texture
    ofImage img;
    ofVboMesh vboMesh;
};
