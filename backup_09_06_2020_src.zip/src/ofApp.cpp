#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    saveBtn.addListener(this, &ofApp::saveBtnHandler);
    saveAsPngBtn.addListener(this, &ofApp::saveAsPngBtnHandler);
    loadSettingsBtn.addListener(this, &ofApp::loadFile);
    
    a1 = 1;
    b1 = 1;
    radius = 200;
    total = 100;
    saveScreen = false;
    
    infoTxt.setup();
    
    
    // LOAD TEXTURE
    ofDisableArbTex();
    //ofEnableNormalizedTexCoords();
    img.load("/Users/alptugan/oF/assets/test2.jpg");
    //img.load("/Users/alptugan/Design/stock/Textures/oavv3DC.jpg");
    //img.getTexture().setTextureWrap( GL_CLAMP_TO_BORDER, GL_CLAMP_TO_BORDER );
    //img.getTexture().setTextureWrap( GL_REPEAT, GL_REPEAT );
    img.getTexture().setTextureWrap( GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE );
    img.getTexture().generateMipmap();
    img.getTexture().setTextureMinMagFilter(GL_NEAREST, GL_NEAREST);
    //img.setUseTexture(true);
    
    
    //world.setMode(OF_PRIMITIVE_TRIANGLES);
    
    ofxGuiSetFont( "../../../../../../assets/fonts/DIN.otf", 8 );
    ofxGuiSetDefaultWidth( 300 );
    ofxGuiSetFillColor(ofColor(255,204,0,200));
    
    string xmlSettingsPath = "settings.xml";
    string xmlMainSettingsPath = "settings_main.xml";
    string xmlSpaceSettingsPath = "settings_spcace.xml";
    
    gui.setup( "Super Formula Generator", xmlSettingsPath );
    gui.setPosition(ofGetWidth() - 310,10);
    sfGui1.setName("Super Formula Parameters 1");
    
    sfGui1.add(m11.set("m1-1 value", 7, 0, 20));
    sfGui1.add(m12.set("m1-2 value", 7, 0, 20));
    sfGui1.add(n11.set("n I-I value", 0.2, 0, 20));
    sfGui1.add(n12.set("n I-II value", 1.7, 0, 20));
    sfGui1.add(n13.set("n I-III value", 1.7, 0, 20));
    sfGui1.add(a1.set("a I value", 1, 0, 1));
    sfGui1.add(b1.set("b I value", 1, 0, 1));
    
    
    sfGui2.setName("Super Formula Parameters 2");
    sfGui2.add(m21.set("m2-1 value", 7, 0, 20));
    sfGui2.add(m22.set("m2-2 value", 7, 0, 20));
    sfGui2.add(n21.set("n II-I value", 0.2, 0, 20));
    sfGui2.add(n22.set("n II-II value", 1.7, 0, 20));
    sfGui2.add(n23.set("n II-III value", 1.7, 0, 20));
    sfGui2.add(a2.set("a II value", 1, 0, 1));
    sfGui2.add(b2.set("b II value", 1, 0, 1));
    
    
    
    meshGui.setName("Mesh Parameters");
    meshGui.add(radius.set("Mesh Radius",200,1,1000));
    meshGui.add(total.set("Mesh Resolution",100,3,1000));
    meshGui.add(strokeColor.set("Stroke Color",ofColor(0,0,0,100),ofColor(0,0,0,0),ofColor(255,255,255,255)));
    meshGui.add(drawWireframe.set("Show Wireframe",true));
    meshGui.add(drawMesh.set("Show Faces",true));
    meshGui.add(setMeshFillMode);
    meshGui.add(fillColor);
    
    
    itemList.setName("Selected Mesh Mode TRIANGLES");
    // Drop down list
    menuItems = {"TRIANGLES","TRIANGLE FAN","TRIANGLE STRIP","LINES","LINE STRIP","LINE LOOP","POINTS"};
    
    items.resize(menuItems.size());
    
    selectedId = 0;
    for (int i = 0; i < menuItems.size(); i++) {
        if(i != 0) {
            items[i].set(menuItems.at(i), false);
            items[i].addListener(this, &ofApp::filesCallback);
        }else{
            items[i].set(menuItems.at(i), true);
        }
        itemList.add(items[i]);
    }
    
    meshGui.add(itemList);
    // end of dropdown
    meshGui.add(animation1.set("Animate",false));
    
    animation2.addListener(this, &ofApp::animation1Handler);
    meshGui.add(animation2.set("Animate Parameters",false));
    
    gui.add(sfGui1);
    gui.add(sfGui2);
    gui.add(meshGui);
    
    gui.getGroup("Mesh Parameters").getGroup("Stroke Color").minimize();
    gui.getGroup("Mesh Parameters").getGroup("Selected Mesh Mode TRIANGLES").minimize();
    
    // Randomize Button
    iterationBtn.addListener(this, &ofApp::iterationBtnHandler);
    gui.add(iterationBtn.setup("Iterate"));
    
    // Lights and Environment
    spaceGUI.setup("Set Lights and Environment Porperties",xmlSpaceSettingsPath);
    spaceGUI.add(invertBg);
    spaceGUI.add(showLight1.set("Show Light A",true));
    spaceGUI.add(light1Pos.set("Light Position A",glm::vec3(0,0,0),glm::vec3(-1000,-1000,-1000),glm::vec3(1000,1000,1000)));
    spaceGUI.setPosition(gui.getPosition().x - gui.getWidth() - 5, gui.getPosition().y);
    
    // MAin Group
    mainGui.setup("Main Parameters",xmlMainSettingsPath);
    mainGui.setPosition(spaceGUI.getPosition().x - spaceGUI.getWidth() - 5, gui.getPosition().y);
    mainGui.add(showGui);
    mainGui.add(info.set("Show Info",true));
    mainGui.add(help.set("Show Help Menu",false));
    
    mainGui.add(fileName);
    mainGui.add(saveBtn.setup("Save Mesh as 3D .ply File"));
    mainGui.add(saveAsPngBtn.setup("Save Mesh as PNG File"));
    mainGui.add(loadSettingsBtn);

    
    
    spaceGUI.loadFromFile(xmlSpaceSettingsPath);
    mainGui.loadFromFile(xmlMainSettingsPath);
    gui.loadFromFile(xmlSettingsPath);

    cout << "Is normalized texture coord. " << ofGetUsingNormalizedTexCoords() << endl;
}

//--------------------------------------------------------------
void ofApp::update(){
    light.setPosition(light1Pos->x, light1Pos->y, light1Pos->z);
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    
    if(saveScreen) {
        //ofBeginSaveScreenAsPDF("test.pdf");
        //ofBeginSaveScreenAsSVG("test2");
        fbo.begin();
        ofClear(1.0,1.0);
        
        ofPushView();
        ofScale(3, 3);
    }
    
   
    if(!invertBg)
        ofBackgroundGradient( ofColor(40,40,40), ofColor(0,0,0), OF_GRADIENT_CIRCULAR);
    else
        ofBackgroundGradient( ofColor(255), ofColor(215), OF_GRADIENT_CIRCULAR);
    
    generateSphereCoord(radius,total);
    
    
    if(saveScreen) {
        //ofEndSaveScreenAsPDF();
        //ofEndSaveScreenAsSVG();
        fbo.end();
        
        fbo.readToPixels(pix);
        
        ofSaveImage(pix,ofGetTimestampString() + ".png");
        
        saveScreen = false;
        
        ofPopView();
    }
    
    if(!saveScreen) {
        infoTxt.setInfoVisible(info);
        infoTxt.setHelpVisible(help);
        infoTxt.draw();
        
        
        if(showGui) {
            gui.draw();
            spaceGUI.draw();
            mainGui.draw();
        }
    }
}
void ofApp::iterationBtnHandler() {
    m11 = ofRandom(m11.getMin(),m11.getMax());
    m12 = ofRandom(m12.getMin(),m12.getMax());
    n11 = ofRandom(n11.getMin(),n11.getMax());
    n12 = ofRandom(n12.getMin(),n12.getMax());
    n13 = ofRandom(n13.getMin(),n13.getMax());
    a1 = ofRandom(a1.getMin(),a1.getMax());
    b1 = ofRandom(b1.getMin(),b1.getMax());
    
    m21 = ofRandom(m21.getMin(),m21.getMax());
    m22 = ofRandom(m22.getMin(),m22.getMax());
    n21 = ofRandom(n21.getMin(),n21.getMax());
    n22 = ofRandom(n22.getMin(),n22.getMax());
    n23 = ofRandom(n23.getMin(),n23.getMax());
    a2 = ofRandom(a2.getMin(),a2.getMax());
    b2 = ofRandom(b2.getMin(),b2.getMax());
    
}

void ofApp:: animation1Handler(bool &_v) {
    
}

void ofApp::loadFile() {
    
    string dataFolder = "../../../" + ofFilePath::getCurrentWorkingDirectory();
    
    //Open the Open File Dialog
    ofFileDialogResult openFileResult = ofSystemLoadDialog("Select xml file", false,  dataFolder + "/data");
    
    //Check if the user opened a file
    if (openFileResult.bSuccess){
        
        //We have a file, check it and process it
        ofFile file (openFileResult.getPath());
        
        if (file.exists()){
            string fileExtension = ofToUpper(file.getExtension());
            
            //We only want xml files
            if (fileExtension == "XML") {
                gui.loadFromFile(openFileResult.getPath());
            }
        }
    }else {
        ofLog() << "User hit cancel";
    }
}

void ofApp::saveBtnHandler() {
    string fileNamePre;
    if(fileName.get() == "") {
        fileNamePre = ofGetTimestampString();
    }else{
        fileNamePre = ofGetTimestampString() + " - " + fileName.get();
    }
    
    world.save(fileNamePre + ".ply");
    gui.saveToFile(fileNamePre + ".xml");
}

void ofApp::saveAsPngBtnHandler() {
    
    
    //ofSaveFrame();
    saveScreen = true;
    //ofSaveViewport("testtt.jpg");
    
    fbo.clear();
    fbo.allocate(ofGetWidth()*3, ofGetHeight()*3,GL_RGBA);
}

float ofApp::superShape(float _theta, float _m1, float _m2, float _n1, float _n2, float _n3, float _a, float _b) {
    
    //_m2 = _m1;
    float t1 = abs((1 / _a) * cos(_m1 * _theta / 4));
    t1 = pow(t1, _n2);
    
    float t2 = abs((1 / _b) * sin(_m2 * _theta / 4));
    t2 = pow(t2, _n3);
    
    float t3 = t1 + t2;
    
    float r = pow(t3, -1 / _n1);
    
    return r;
}

void ofApp::generateSphereCoord(float _r,int _t) {
    //vector<glm::vec3> coor;
    //coor.resize((_t+1));
    ofEnableDepthTest();
    world.clear();
    for (int i= 0; i < total; i++) {
        
        float lat = ofMap(i,0,total-1,-HALF_PI,HALF_PI);
        
        float r2 = superShape(lat, m11, m21, n11, n12, n13, a1, b1);
        
        for (int j= 0; j<total; j++) {
            int c1 = ofMap(i, 0, total, 0, 255 );
            float lon = ofMap(j,0,total-1,-PI,PI);
            
            float r1 = superShape(lon, m21, m22, n21, n22, n23, a2, b2);
            
            
            float x = _r * r1 * cos(lon) * r2 * cos(lat);
            float y = _r * r1 * sin(lon) * r2 * cos(lat);
            float z = _r * r2 * sin(lat);
            
            ofColor hueColor = ofColor(255,255,255);
            hueColor.setHue(c1 % 255);
            
            world.addVertex(glm::vec3(x,y,z));
            
            if(setMeshFillMode == 0)
                world.addColor(hueColor);
            else if(setMeshFillMode == 1)
                world.addColor(fillColor.get());
            else if(setMeshFillMode == 2)
                world.addColor(ofColor(255));
            
            if(setMeshFillMode == 2) {
                world.addTexCoord( img.getTexture().getCoordFromPercent(0,0) );
                world.addTexCoord( img.getTexture().getCoordFromPercent(1,0) );
                world.addTexCoord( img.getTexture().getCoordFromPercent(1,1) );
                world.addTexCoord( img.getTexture().getCoordFromPercent(0,1) );
            }
        }
    }

    
    
    for (int j = 0; j < total - 1; j++) {
        for (int i = 0 ; i < total - 1 ; i++) {
            
            world.addIndex(i+j*total);         // 0
            world.addIndex((i+1)+j*total);     // 1
            world.addIndex(i+(j+1)*total);     // 6
            
            world.addIndex((i+1)+j*total);     // 1
            world.addIndex((i+1)+(j+1)*total); // 7
            world.addIndex(i+(j+1)*total);     // 6
        
        }
    }

    //createTextureMap();
    if(setMeshFillMode == 2) {
        world.addTexCoord( glm::vec2(0,0));
        world.addTexCoord( glm::vec2(10000, 0));
        world.addTexCoord( glm::vec2(10000, 10000));
        world.addTexCoord( glm::vec2(0, 10000));
    }
    
    ofEnableLighting();
    light.enable();
    cam.begin();
  
    ofPushMatrix();
    if(animation1) {
        rotValX = rotValX + 0.5;
    }
    ofRotateYDeg(rotValX);
    ofRotateXDeg(rotValX);
    
    world.enableColors();
    //world.enableTextures();
    
    //ofSetColor(255,255);
    //ofFloatColor color(1.0,1.0,1.0,1.0);
    //glTexParameterfv(GL_TEXTURE_RECTANGLE, GL_TEXTURE_BORDER_COLOR, &color.r);
    img.getTexture().bind();
    if(drawMesh)
        world.draw();
    img.getTexture().unbind();
    
    world.disableColors();
    if(drawWireframe) {
        ofPushStyle();
        ofSetColor(strokeColor->r,strokeColor->g,strokeColor->b, strokeColor->a);
        world.drawWireframe();
        ofPopStyle();
    }
    ofPopMatrix();
    
    if(showLight1)
        light.draw();
    
    cam.end();
    light.disable();
    ofDisableLighting();
    ofDisableDepthTest();
    
}

//----------------------------------------------------------
ofMesh ofApp::sphereCustom( float radius, int res, ofPrimitiveMode mode ) {
    
    ofMesh mesh;
    
    float doubleRes = res*2.f;
    float polarInc = PI/(res); // ringAngle
    float azimInc = TWO_PI/(doubleRes); // segAngle //
    
    if(mode != OF_PRIMITIVE_TRIANGLE_STRIP && mode != OF_PRIMITIVE_TRIANGLES) {
        mode = OF_PRIMITIVE_TRIANGLE_STRIP;
    }
    mesh.setMode(mode);
    
    glm::vec3 vert;
    ofVec2f tcoord;
    
    for(float i = 0; i < res+1; i++) {
        
        float tr = sin( PI-i * polarInc );
        float ny = cos( PI-i * polarInc );
        
        tcoord.y = i / res;
        
        for(float j = 0; j <= doubleRes; j++) {
            
            float nx = tr * sin(j * azimInc);
            float nz = tr * cos(j * azimInc);
            
            tcoord.x = j / (doubleRes);
            
            vert = glm::vec3(nx, ny, nz);
            mesh.addNormal(vert);
            vert *= radius;
            mesh.addVertex(vert);
            mesh.addTexCoord(tcoord);
        }
    }
    
    int nr = doubleRes+1;
    if(mode == OF_PRIMITIVE_TRIANGLES) {
        
        int index1, index2, index3;
        
        for(float iy = 0; iy < res; iy++) {
            for(float ix = 0; ix < doubleRes; ix++) {
                
                // first tri //
                if(iy > 0) {
                    index1 = (iy+0) * (nr) + (ix+0);
                    index2 = (iy+0) * (nr) + (ix+1);
                    index3 = (iy+1) * (nr) + (ix+0);
                    
                    mesh.addIndex(index1);
                    mesh.addIndex(index3);
                    mesh.addIndex(index2);
                }
                
                if(iy < res-1 ) {
                    // second tri //
                    index1 = (iy+0) * (nr) + (ix+1);
                    index2 = (iy+1) * (nr) + (ix+1);
                    index3 = (iy+1) * (nr) + (ix+0);
                    
                    mesh.addIndex(index1);
                    mesh.addIndex(index3);
                    mesh.addIndex(index2);
                    
                }
            }
        }
        
    } else {
        for(int y = 0; y < res; y++) {
            for(int x = 0; x <= doubleRes; x++) {
                mesh.addIndex( (y)*nr + x );
                mesh.addIndex( (y+1)*nr + x );
            }
        }
    }
    
    
    return mesh;
}





// ------------------------------------------------------------
glm::vec3 ofApp::randomPointOnSphere()
{
    float lambda = ofRandom(1.0f);
    float u = ofRandom(-1.0f, 1.0f);
    float phi = ofRandom( 2.0 * PI );
    
    glm::vec3 p;
    p.x = pow(lambda, 1/3) * sqrt(1.0 - u * u) * cos(phi);
    p.y = pow(lambda, 1/3) * sqrt(1.0 - u * u) * sin(phi);
    p.z = pow(lambda, 1/3) * u;
    
    return p;
}

void ofApp::filesCallback(bool & _val) {
    
    int i;
    
    if(_val) {
        for(i = 0; i < menuItems.size(); i++){
            if(&items[i].get() == &_val){
                selectedId = i;
                break;
            }
        }
        
        
        for(int i = 0; i < menuItems.size(); i++){
            items[i].removeListener(this, &ofApp::filesCallback);
            items[i].set(false);
            items[i].addListener(this, &ofApp::filesCallback);
        }
        
        items[selectedId] = true;
    }
    
    
    if(selectedId == 0) {
        world.setMode(OF_PRIMITIVE_TRIANGLES);
    }else if(selectedId == 1) {
        world.setMode(OF_PRIMITIVE_TRIANGLE_FAN);
    }else if(selectedId == 2) {
        world.setMode(OF_PRIMITIVE_TRIANGLE_STRIP);
    }else if(selectedId == 3) {
        world.setMode(OF_PRIMITIVE_LINES);
    }else if(selectedId == 4) {
        world.setMode(OF_PRIMITIVE_LINE_STRIP);
    }else if(selectedId == 5) {
        world.setMode(OF_PRIMITIVE_LINE_LOOP);
    }else if(selectedId == 6) {
        world.setMode(OF_PRIMITIVE_POINTS);
    }
    
    itemList.setName("Selected Mesh Mode " + items[selectedId].getName());
    gui.getGroup("Mesh Parameters").getGroup("Selected Mesh Mode " + items[selectedId].getName()).minimize();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    if(key=='f') {
        ofToggleFullscreen();
    }
    
    else if(key=='g') {
        showGui = !showGui;
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    gui.setPosition(ofGetWidth() - 310,10);
    spaceGUI.setPosition(gui.getPosition().x - gui.getWidth() - 5, gui.getPosition().y);
    mainGui.setPosition(spaceGUI.getPosition().x - spaceGUI.getWidth() - 5, gui.getPosition().y);
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
