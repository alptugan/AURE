#include "ofMain.h"
#include "ofApp.h"

//========================================================================
int main( ){
    ofGLWindowSettings settings;
    
    settings.setGLVersion(2,1);
    
    // Sonar AV size
    settings.setSize(1920, 1080);
    
    ofCreateWindow(settings);
    
    // this kicks off the running of my app
    // can be OF_WINDOW or OF_FULLSCREEN
    // pass in width and height too:
    //ofRunApp(new ofApp());
    
    // ofxFilikaApp
    ofRunAppWithAppUtils(new ofApp());
}
